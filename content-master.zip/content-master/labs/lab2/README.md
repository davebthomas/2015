# Files for Lab 2 of CS109

## Part A

* [Lab_2_A_Live.ipynb](http://nbviewer.ipython.org/github/cs109/content/blob/master/labs/lab2/Lab_2_A_Live.ipynb) - starting point for lab
* [Lab_2_A_Johanna.ipynb](http://nbviewer.ipython.org/github/cs109/content/blob/master/labs/lab2/Lab_2_A_Johanna.ipynb) - Johanna's original writeup
* [Lab_2_A_Live_Ray_Final.ipynb](http://nbviewer.ipython.org/github/cs109/content/blob/master/labs/lab2/Lab_2_A_Live_Ray_Final.ipynb) - Ray's in-class reconstruction

## Part B

* [Lab_2_B.ipynb](http://nbviewer.ipython.org/github/cs109/content/blob/master/labs/lab2/Lab_2_B.ipynb) - Reddit example
